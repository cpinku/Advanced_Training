package net.springboot.java;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
