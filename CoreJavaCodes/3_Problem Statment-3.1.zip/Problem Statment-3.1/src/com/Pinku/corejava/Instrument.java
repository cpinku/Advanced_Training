package com.Pinku.corejava;

public abstract class Instrument {
	public abstract void play();
}
