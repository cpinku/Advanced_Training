package com/Pinku/corejava;

public class med {
	public void displayLabel() {
		System.out.println("Company : Globex Pharma");
		System.out.println("Address : Bangalore");
	}
}

class Tablet extends med {

	public void displayLabel() {
		System.out.println("store in a cool dry place");
	}
}

class Syrup extends med{
	public void displayLabel() {
		System.out.println("Consumption as directed by thephysician");
	}
}

class Ointment extends med {
	public void displayLabel() {
		System.out.println("for external use only");
	}
}